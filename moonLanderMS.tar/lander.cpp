/***********************************************************************
 * Implementation File:
 *    LANDER : A class representing the Lander
 * Author:
 *    Gavin Marler
 * Summary:
 *    Everything you needed to know about the ground but were afraid to ask
 ************************************************************************/

#include "lander.h"

void Lander :: applyGravity(float gravity)
{
   
}

void Lander :: applyThrustLeft()
{
   
}

void Lander :: applyThrustRight()
{
   
}

void Lander :: applyThrustBottom()
{
   
}

void Lander :: advance()
{
   
}

void Lander :: draw()
{
   drawLander(point);
}

Lander :: Lander()
{
   
}
