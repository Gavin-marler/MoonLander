/***********************************************************************
 * Implementation File:
 *    VELOCITY : A class representing the Lander
 * Author:
 *    Gavin Marler
 * Summary:
 *    Everything you needed to know about the ground but were afraid to ask
 ************************************************************************/

#include "velocity.h"

Velocity :: Velocity()
{
   
}

Velocity :: Velocity(float Dx, float Dy)
{
   
}
